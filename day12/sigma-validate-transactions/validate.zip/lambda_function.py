import json
import boto3
import os

s3 = boto3.client("s3")

BUCKET = os.environ.get("SIGMA_S3_BUCKET", "sigma-datatech-676382")


def is_valid(record):
    if not record.get("transaction_id"):
        return False

    if float(record.get("amount", 0)) <= 0:
        return False

    if not record.get("merchant_name"):
        return False

    if not record.get("transaction_date"):
        return False

    return True


def lambda_handler(event, context):

    for record in event["Records"]:

        bucket = record["s3"]["bucket"]["name"]
        key = record["s3"]["object"]["key"]

        response = s3.get_object(
            Bucket=bucket,
            Key=key
        )

        data = json.loads(
            response["Body"].read().decode()
        )

        clean_records = []
        bad_records = []

        for row in data:

            if is_valid(row):
                clean_records.append(row)
            else:
                bad_records.append(row)

        clean_key = key.replace(
            "bronze/",
            "clean/"
        )

        s3.put_object(
            Bucket=bucket,
            Key=clean_key,
            Body=json.dumps(clean_records)
        )

        if bad_records:

            quarantine_key = key.replace(
                "bronze/",
                "quarantine/"
            )

            s3.put_object(
                Bucket=bucket,
                Key=quarantine_key,
                Body=json.dumps(bad_records)
            )

    return {
        "statusCode": 200
    }